require 'test_helper'

class ProfileHelperTest < ActionView::TestCase
end
