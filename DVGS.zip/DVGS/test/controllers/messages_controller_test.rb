require 'test_helper'

class MessagesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
