Rails.application.routes.draw do

  devise_for :users
  resources :messages do
    resources :comments
  end
  root 'messages#index'
  
  get '/about' => 'messages#about'
  get '/profile' => 'profile#index'
  get '/profile/'
end
