class Profile < ActiveRecord::Base
    belongs_to :users
end
