class ProfileController < ApplicationController
    
    def create
        @message = Message.find(params[:message_id])
        @profile = @message.comments.create(comment_params)
        @profile.user_id = current_user.id
        
        if @profile.save
            redirect_to profile_path(@profile)
        else
            render 'new'
        end
    end
    
    def edit
    end
end
