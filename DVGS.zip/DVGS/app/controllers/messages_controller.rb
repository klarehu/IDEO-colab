class MessagesController < ApplicationController
    
    # Append a callback before all other actions
    # Find_message goes first 
    # No need to authenticate user for index and show as they should be available to non-users alike
    before_action :find_message, only: [:show, :edit, :update, :destroy]
    before_action :authenticate_user!, except: [:index, :show, :about]
    
    # Define what should be on the default page of the app
    def index
        @messages = Message.all.order("created_at DESC")
    end
    
    # When specific message is clicked, show
    def show
        @message = Message.find(params[:id])
    end
    
    # When 'New Message' is clicked, redirect user to build page
    def new
        @message = current_user.messages.build
    end
    
    # When 'Create Message' is clicked, save message and redirect to index
    def create
        @message = current_user.messages.build(message_params)
        if @message.save
            redirect_to root_path
        else
            render 'new'
        end
    end
    
    # Allow ability to edit message (only to the one who created it)
    def edit
    end
    
    # Allow ability to update or edit the messages
    def update
        if @message.update(message_params)
            redirect_to message_path
        else
            render 'edit'
        end
    end
    
    def destroy
        @message.destroy
        redirect_to root_path
    end
    
    def about
    end
    
    private
    
    def message_params
        params.require(:message).permit(:title, :description)
    end
    
    def find_message
        @message = Message.find(params[:id])
    end
end
